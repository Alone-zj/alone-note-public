

https://dl.min.io/server/minio/release/windows-amd64/archive/

```
minio.exe server d:\minio\Data --console-address ":9001"
```





